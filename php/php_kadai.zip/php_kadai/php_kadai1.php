<html>
    <head>
        <title>式と演算子課題(1)</title>
    </head>
    <body>

    <p>(1)</p>
    <?php
    $a = 'abc';
    $b = 'abc';
    if (strcasecmp($a, $b) == 0) {
        echo 'Match <br/>';
    }else{
        echo 'Not match';
    }
    ?>

    <p>(2)</p>

    <?php
    $str1 = '山田' ;
    $str2 = '太郎' ;
    echo $str1 . $str2;
    ?>

    <p>(3)</p>
    <?php
    $a = 'こんにちは' ;
    $b = 1212 ;
    echo $a . $b ;
    ?>

    <p>(4)</p>
    <?php
    define(GREET, 'こんにちは') ;
    echo GREET ;
    echo '<br>' ;
    const a1 = 'さようなら' ;
    echo a1 ;
    ?>

    <p>(5)</p>
    <?php
      echo 'ファイル名： '. __FILE__;
      echo '<br />';
      echo '行数： '. __LINE__;
    ?>

    <p>(6)</p>
    <?php
    $a = 300 ;
    echo $a / 365 ;
    ?>

    <p>(7)</p>
    <?php
    $t = 4;
    echo '4 + 1 = '. $t++ . 'です。';
    ?>

    <p>(8)</p>
    <?php
    $a = 3;
    echo '3 - 1 = '. $a-- . 'です。';
    ?>

    <p>(9)</p>
    <?php
    $a = 5;
    $b = ++$a;
    $c = $b--;
    echo $b + $c;
    ?>

    <p>(10)</p>
    <?php
    $a = 3;
    $b = 2;
    echo $a + $b ;
    ?>

    <p>(11)</p>
    <?php
    $num = 1234;
    $s = (string)$num;
    var_dump($s);
    ?>

    <p>(12)</p>
    <?php
    $locations = 3;
    $c = $locations + 2;
    echo $c;
    ?>





    </body>
</html>
