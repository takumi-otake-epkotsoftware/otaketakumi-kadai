<html>
    <head>
        <title>式と演算子課題(2)</title>
    </head>
    <body>
        <p>(1)</p>
        <p>.</p>
        <?php
        echo 2 + 4 - 5;
        echo '<br>';
        echo 4 - 5 + 2;
        ?>
        <p>.</p>
        <?php
        echo 4 * 5 / 2;
        echo '<br>';
        echo 5 / 2 * 4;
        ?>

        <p>(2)</p>
        <?php
        echo 2 * 3 + 4 + 1;
        echo '<br>';
        echo 2 * (3 + 4 +1);
        ?>

        <p>(3)</p>
        <div>$username == "Admin"</div>
        <div>$username !== "Admin"</div>

        <p>(4)</p>
        <?php
        $array = ["赤", "青", "黄", "緑", "黒"];
        foreach($array as $value) {
            echo$value;
            echo'<br/>';
        }
        ?>

        <p>(5)</p>
        <?php
        $colors = ["赤", "青", "黄", "緑", "黒"];
        $i = 0;
        sort($colors);
        while ($i < count($colors)){
            echo $colors[$i];
            $i++;
            echo '<br/>';
        }
        ?>

        <p>(6)</p>
        <?php
        $fruits = [
            ["apple", "cherry", "pear", "banana"],
            ["grape", "pineapple", "melon", "pumpkin"],
            ["avocado", "acerola", "strawberry", "orange"]
        ];
        echo '<br/>';
        foreach ($fruits as $key_a => $val_a) {
            foreach ($val_a as $key_b => $val_b) {
                echo $key_a . '：' . $key_b . '：' . $val_b . '<br/>';
            }
        }
        echo '<br/>';
        $key_a = 0;
        $key_b = 0;
        while ($key_a < count($fruits)) {
            while ($key_b < count($fruits[$key_a])) {
                echo $key_a . '：' . $key_b . '：' . $fruits[$key_a][$key_b] . '<br/>';
                $key_b++;
            }
            $key_b = 0;
            $key_a++;
        }
        ?>




    </body>
</html>