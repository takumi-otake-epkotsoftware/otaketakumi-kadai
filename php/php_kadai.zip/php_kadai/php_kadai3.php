<html>
    <head>
        <title>制御構文課題</title>
    </head>
    <body>
        <p>(1)</p>
        <?php
        $num = rand(-10,10);
        if($num > 0){
            echo $num. 'は正の整数です。<dr/>';
        }elseif($num < 0){
            echo $num. 'は負の整数です。<br/>';
        }else{
            echo $num. 'はゼロです。<br/>';
        }
        ?>

        <p>(2)</p>
        <?php
        $num = rand(1,2);
        $result = $num == 1 ? '結果は1です。' : '結果は2です。';
        echo $result;
        ?>

        <p>(3)</p>
        <?php
        $num = rand(1,4);
        switch($num){
            case 1:
                echo '値は1です。';
                break;
            case 2:
                echo '値は2です。';
                break;
            case 3:
                echo '値は3です。';
                break;
            case 4:
                echo '値は4です。';
                break;
        }
        ?>
        <p>(4)</p>
        予測: breakがないので、出た値以下の処理が連続して行われる。<br/>

        <?php
        $num = rand(1, 4);
        switch ($num) {
            case 1:
                echo "値は1です。";
            case 2:
                echo "値は2です.";
            case 3:
                echo "値は3です。";
            case 4:
                echo "値は4です。";
        }
    ?>
    <p>(5)</p>
    <?php
        $num = rand(1,6);
        switch($num){
            case 1:
                echo '値は1です。';
                break;
            case 2:
                echo '値は2です。';
                break;
            case 3:
                echo '値は3です。';
                break;
            case 4:
                echo '値は4です。';
                break;
            default:
                echo 'エラーです。';
            }
        ?>

        <p>(6)</p>

        <?php
        $num = rand(1,4);
        switch($num):
            case 1:
                echo '値は1です。';
                break;
            case 2:
                echo '値は2です。';
                break;
            case 3:
                echo '値は3です。';
                break;
            case 4:
                echo '値は4です。';
                break;
        endswitch;
        ?>

        <p>(7)</p>
        
        <?php
        $count = 1;
        while($count < 11){
            echo $count. '回目のループです。<br/>';
            $count++;
        }
        ?>
        
        <p>(8)</p>

        <?php
        $count = 1;
        do {
            echo $count. '回目のループです。<br/>';
            $count++;
        }while($count < 11);
        ?>

        <p>(9)</p>
        <?php
        for($counter = -3; $counter < 10; $counter++){
            if($counter == 0){
                break;
            }else{
				echo 100 / $counter. '<br/>';
            }
        }
        ?>

        <p>(10)</p>
        <?php
        for($counter = -3; $counter < 10; $counter++){
            if($counter == 0){
                continue;
            }else{
				echo 100 / $counter. '<br/>';
            }
        }
        ?>





    </body>
</html>