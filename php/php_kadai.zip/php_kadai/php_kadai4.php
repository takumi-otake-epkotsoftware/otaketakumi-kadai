<html>
    <head>
        <title>配列課題</title>
    </head>
    <body>
        <p>(1)</p>
        <?php
        $day = ["月曜日", "火曜日", "水曜日", "木曜日", "金曜日"];
        print_r($day);
        ?>

        <p>(2)</p>
        <?php
        $translate = ["cat" => "猫", "dog" => "犬", "mouse" => "鼠", "caw" => "牛"];
        print_r($translate);
        ?>

        <p>(3)</p>
        <?php
        $day = ["月曜日", "火曜日", "水曜日", "木曜日", "金曜日"];
        $translate = ["cat" => "猫", "dog" => "犬", "mouse" => "鼠", "caw" => "牛"];
        echo $day[3];
        echo '<br/>';
        echo $translate ["caw"];
        ?>

        <p>(4)</p>
        <?php
          $day = ["月曜日", "火曜日", "水曜日", "木曜日", "金曜日"];
          $translate = ["cat" => "猫", "dog" => "犬", "mouse" => "鼠", "caw" => "牛"];
          $cnt_day = count($day);
          $cnt_t = count($translate);
          echo '(1) => '.$cnt_day;
          echo '<br/>';
          echo '(2) => '.$cnt_t;
        ?>

        <p>(5)</p>
        <?php
          $array = [
              ['田中', 23, '女性'],
              ['加藤', 34, '女性'],
              ['井上', 22, '男性'],
              ['小宮', 27, '男性'],
              ['キム', 44, '男性'],
          ];
          foreach($array as $value){
              echo $value[0]. '('.$value[1]. '歳' .$value[2].')';
              echo '<br/>';
          }
        ?>



    </body>
</html>