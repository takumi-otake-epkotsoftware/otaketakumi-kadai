<html>
    <head>
        <title>関数課題</title>
    </head>
    <body>
        <p>関数課題(1)</p>
        <?php
          include "./php_kadai5_function.php";
          $a = 1;
          $b = 5;

          echo '第一引数 => '.$a. '、第二引数 => '.$b;
          echo '<br/><br/>';

          echo '足し算の結果 => '.add($a, $b);
          echo '<br/>';

          echo '引き算の結果 => '.sub($a, $b);
          echo '<br/>';

          echo '掛け算の結果 => '.mul($a, $b);
          echo '<br/>';

          echo '割り算の結果 => '.div($a, $b);
          echo '<br/>';

          echo '割り算の余り => '.div_rem($a, $b);
          echo '<br/>';
        ?>

        <p>(2)</p>
        <?php
          $a = 10;
          $b = 5;

          echo '第一引数 => '.$a. '、第二引数 => '.$b;
          echo '<br/><br/>';

          echo '足し算の結果 => '.add_2($a, $b);
          echo '<br/>';

          echo '引き算の結果 => '.sub_2($a, $b);
          echo '<br/>';

          echo '掛け算の結果 => '.mul_2($a, $b);
          echo '<br/>';

          echo '割り算の結果 => '.div($a, $b);
          echo '<br/>';

          echo '割り算の余り => '.div_rem_2($a, $b);
        ?>


    </body>
</html>