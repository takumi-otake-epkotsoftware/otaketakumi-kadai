<?php
  function add($a, $b){
      $a = $a + $b;
      return $a;
  }

  function sub($a, $b){
      $a = $a - $b;
      return $a;
  }

  function mul($a, $b){
      $a = $a * $b;
      return $a;
  }

  function div($a, $b){
      $a = $a / $b;
      return $a;
  }

  function div_rem($a, $b){
      $a = $a % $b;
      return $a;
  }

  function add_2(&$a, &$b){
	  $a = $a + $b;
	  return $a;
  }

  function sub_2(&$a, &$b){
	  $a = $a - $b;
	  return $a;
  }

  function mul_2(&$a, &$b){
	  $a = $a * $b;
	  return $a;
  }

  function div_2(&$a, &$b){
	  $a = $a / $b;
	  return $a;
  }

  function div_rem_2(&$a, &$b){
	  $a = $a % $b;
	  return $a;
  }
?>